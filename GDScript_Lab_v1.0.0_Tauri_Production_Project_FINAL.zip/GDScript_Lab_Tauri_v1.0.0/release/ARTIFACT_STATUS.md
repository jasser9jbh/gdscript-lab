# v1.0.0 Artifact Status

## Ready in this source package

- `GDScript_Lab_v1.0.0_Portable.html` — public portable HTML edition.
- Full Tauri 2 source/configuration for Windows, Linux, macOS, Android and iOS.
- Native CI build workflows.
- Native integration validation evidence.

## Not fabricated in this source package

No native binary was manufactured or renamed without a real platform build. These must be generated on the included native CI/native hosts:

- Windows `.exe` / `.msi`
- Linux `.AppImage` / `.deb`
- Android `.apk` / `.aab`
- macOS `.app` / `.dmg`
- iOS signed archive

See `../BUILD_ATTEMPT_REPORT.md` for the exact sandbox build limitations and `../README_DISTRIBUTION.md` for the public-release gate.
