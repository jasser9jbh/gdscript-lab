# GDScript Lab v1.0.0 — Build Guide

This repository is the native Tauri 2 application wrapper around the frozen GDScript Lab course payload.

## Pinned release toolchain

- Node.js: **22.16.0** in CI
- Rust: **1.98.0** (`rust-toolchain.toml`)
- Tauri crate: **2.11.5**
- Tauri CLI: **2.11.4**
- opener plugin: **2.5.4**
- dialog plugin: **2.7.3**
- fs plugin: **2.5.1**
- Android minimum: **API 24 / Android 7.0**
- iOS minimum: **14.0**

Run this first on any build host:

```bash
python scripts/check-build-env.py
python scripts/audit.py
```

The audit verifies the frozen course hash, inventory, native CSP/IPC allowance, minimal capabilities and absence of automatic remote-content loading.

## First connected build

The source archive intentionally does not contain `node_modules`, Cargo registry data, Android SDK/NDK, or private signing credentials. A connected build host must install dependencies once:

```bash
npm install
npm run icons
```

`npm install` creates `package-lock.json`; Cargo creates `src-tauri/Cargo.lock` on the first Rust resolution/build. Preserve those generated lock files in the private release repository/tag used to produce final store binaries if you want byte-for-byte dependency resolution reproducibility across rebuilds.

## Windows

Install Microsoft C++ Build Tools / Windows SDK, Rust MSVC, Node 22.16.0, and WebView2 build prerequisites.

```powershell
npm install
npm run icons
python scripts/audit.py
npm run build:windows
```

Expected outputs are under `src-tauri/target/release/bundle/nsis/` and `.../msi/`.

For a larger installer that carries the WebView2 runtime instead of downloading the bootstrapper:

```powershell
npm run build:windows:offline
```

Public commercial installers should be code-signed before distribution.

## Linux

Install the Tauri Linux development prerequisites, including WebKitGTK 4.1, GTK 3, librsvg and patchelf. On Ubuntu 22.04 the included CI workflow installs the required packages.

```bash
npm install
npm run icons
python3 scripts/audit.py
npm run build:linux
```

Expected outputs: AppImage + Debian package. Build Linux release artifacts on the oldest glibc baseline you intend to support.

## macOS

Requires macOS with Xcode/Command Line Tools, Node and Rust.

```bash
npm install
npm run icons
python3 scripts/audit.py
npm run build:macos
```

The desktop CI builds both Apple Silicon and Intel targets. Public direct-download builds should use Developer ID signing and notarization.

## Android

Install Android Studio / SDK command-line tools, platform tools, Build-Tools, a side-by-side NDK, Java, and the four Rust Android targets. Set `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) and `NDK_HOME`.

```bash
npm install
npm run icons
npm run android:init
npm run android:apk
npm run android:aab
```

- `android:apk` creates a universal APK.
- `android:aab` creates the Google Play bundle.
- Production distribution requires your private signing key.

The included GitHub workflow accepts these repository secrets:

- `ANDROID_KEY_BASE64`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEYSTORE_PASSWORD` (optional; falls back to `ANDROID_KEY_PASSWORD`)

The signing helper is idempotent and is unit-tested in this source package. Never commit the generated keystore, `keystore.properties`, or passwords.

## iOS

Requires **macOS + full Xcode + CocoaPods**. iOS cannot be compiled on Linux or Windows.

```bash
npm install
npm run icons
npm run ios:init
npm run ios:build
```

The included command performs an unsigned build check. App Store/TestFlight distribution requires an Apple Developer identity and provisioning profile.

## GitHub Actions

The repository contains:

- `.github/workflows/desktop-build.yml`
- `.github/workflows/android-build.yml`
- `.github/workflows/ios-build.yml`

They provision the appropriate hosted runner/toolchains and run `scripts/audit.py` before building. Desktop tag builds create a **draft** GitHub release rather than publishing unsigned artifacts automatically.

## Important native-webview detail

The portable HTML intentionally keeps `connect-src 'none'`. The Tauri frontend must instead allow Tauri's internal IPC endpoints:

```text
connect-src ipc: http://ipc.localhost
```

This does **not** grant arbitrary internet requests. GDScript Lab still contains no automatic HTTP client; the native opener is separately scoped to the three user-clickable domains listed in the capabilities files.
