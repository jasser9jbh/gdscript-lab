# GDScript Lab v1.0.0 — Release Checklist

## Source/frozen-content gate

- [x] Frozen portable HTML preserved (`743e2f2d038681473ee20989892f6a306f758b4d03ff4e9989826e082daab822`)
- [x] COURSE_DATA byte-identical in Tauri frontend (`569bc1d6e94096f495345274bc5083053e1d5fd9af4262d4549cb08cde6b5880`)
- [x] 183/183 learner-visible code/command strings unchanged
- [x] 27 modules / 171 lessons / 183 code-command blocks / 310 glossary / 143 reference / 10 projects
- [x] Tauri frontend JavaScript syntax checked
- [x] Native-mock browser regression: 171/171 lessons, zero page/console errors, zero 320px overflow

## Native-shell gate

- [x] Mobile safe-area CSS
- [x] Native external-link opener
- [x] Native Save dialog + filesystem text export
- [x] Native export/opener failure paths fail visibly instead of unsafe WebView fallback
- [x] Portable browser export fallback retained only outside Tauri
- [x] Tauri IPC CSP fixed (`connect-src ipc: http://ipc.localhost`)
- [x] No updater / analytics / automatic HTTP client added
- [x] Opener restricted to docs.godotengine.org, godotengine.org and jbhprods.com
- [x] Dialog permission reduced to Save only
- [x] Filesystem permission reduced to text writes
- [x] Android signing helper corrected and unit-tested
- [x] GitHub secret conditional corrected to use job environment variables
- [x] Windows/Linux/macOS/Android/iOS build commands included
- [x] Native CI workflows included

## Final public binary gate — must be completed on real native build hosts

- [ ] Run connected dependency resolution and preserve `package-lock.json` + `src-tauri/Cargo.lock` for the final release tag
- [ ] Generate/review third-party license inventory from that locked dependency graph
- [ ] Build Linux `.AppImage` + `.deb`
- [ ] Build Windows `.exe`/`.msi` on Windows
- [ ] Build Android `.apk`/`.aab` with Android SDK/NDK
- [ ] Build macOS `.app`/`.dmg` on macOS
- [ ] Build iOS archive on macOS/Xcode if releasing iOS
- [ ] Add production signing secrets/certificates in the private release environment
- [ ] Sign/notarize the artifacts appropriate to each platform
- [ ] Run the real-device/OS smoke test in `README_DISTRIBUTION.md`
- [ ] Submit/store-listing metadata/screenshots where applicable
