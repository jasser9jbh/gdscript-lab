#!/usr/bin/env python3
from __future__ import annotations
import os, platform, shutil, subprocess, json
from pathlib import Path


def cmd_version(cmd, args=("--version",)):
    exe = shutil.which(cmd)
    if not exe:
        return {"found": False, "path": None, "version": None}
    try:
        p = subprocess.run([exe, *args], capture_output=True, text=True, timeout=8)
        out = (p.stdout or p.stderr).strip().splitlines()
        version = out[0] if out else f"exit {p.returncode}"
    except Exception as e:
        version = f"error: {e}"
    return {"found": True, "path": exe, "version": version}


def pkg_config(name):
    if not shutil.which("pkg-config"):
        return False
    return subprocess.run(["pkg-config", "--exists", name]).returncode == 0

report = {
    "host": {"system": platform.system(), "release": platform.release(), "machine": platform.machine()},
    "tools": {k: cmd_version(k) for k in ["node","npm","rustc","cargo","java","javac","clang","gcc","pkg-config","sdkmanager","adb","gradle","xcodebuild"]},
    "env": {k: os.environ.get(k) for k in ["JAVA_HOME","ANDROID_HOME","ANDROID_SDK_ROOT","NDK_HOME"]},
    "linux_dev_packages": {
        "webkit2gtk-4.1": pkg_config("webkit2gtk-4.1"),
        "gtk+-3.0": pkg_config("gtk+-3.0"),
        "librsvg-2.0": pkg_config("librsvg-2.0"),
    },
}

system = report["host"]["system"]
linux_ready = all(report["tools"][k]["found"] for k in ["node","npm","rustc","cargo"]) and all(report["linux_dev_packages"].values()) if system == "Linux" else None
android_ready = all(report["tools"][k]["found"] for k in ["node","npm","rustc","cargo","java","sdkmanager"]) and bool(report["env"]["ANDROID_HOME"] or report["env"]["ANDROID_SDK_ROOT"]) and bool(report["env"]["NDK_HOME"])
ios_ready = system == "Darwin" and all(report["tools"][k]["found"] for k in ["node","npm","rustc","cargo","xcodebuild"])
windows_ready = system == "Windows" and all(report["tools"][k]["found"] for k in ["node","npm","rustc","cargo"])
macos_ready = system == "Darwin" and all(report["tools"][k]["found"] for k in ["node","npm","rustc","cargo","xcodebuild"])
report["readiness"] = {"linux": linux_ready, "android": android_ready, "windows": windows_ready, "macos": macos_ready, "ios": ios_ready}

print(json.dumps(report, indent=2))
