#!/usr/bin/env python3
from pathlib import Path

p=Path('src-tauri/gen/android/app/build.gradle.kts')
if not p.exists():
    raise SystemExit('Android project not initialized; run npm run android:init first.')
t=p.read_text('utf-8')
if 'keystore.properties' in t:
    print('Android signing already configured.')
    raise SystemExit(0)
if 'import java.util.Properties' not in t:
    t='import java.util.Properties\nimport java.io.FileInputStream\n'+t
marker='    buildTypes {'
insert='''    signingConfigs {
        create("release") {
            val keystorePropertiesFile = rootProject.file("keystore.properties")
            val keystoreProperties = Properties()
            if (keystorePropertiesFile.exists()) {
                keystoreProperties.load(FileInputStream(keystorePropertiesFile))
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = (keystoreProperties["keyPassword"] ?: keystoreProperties["password"]) as String
                storeFile = file(keystoreProperties["storeFile"] as String)
                storePassword = (keystoreProperties["storePassword"] ?: keystoreProperties["password"]) as String
            }
        }
    }

'''
if marker not in t:
    raise SystemExit('Could not locate buildTypes block.')
t=t.replace(marker,insert+marker,1)
release='        getByName("release") {'
if release not in t:
    raise SystemExit('Could not locate release build type.')
t=t.replace(
    release,
    release+'\n            if (rootProject.file("keystore.properties").exists()) signingConfig = signingConfigs.getByName("release")',
    1,
)
p.write_text(t,'utf-8')
print('Android signing configuration patched.')
