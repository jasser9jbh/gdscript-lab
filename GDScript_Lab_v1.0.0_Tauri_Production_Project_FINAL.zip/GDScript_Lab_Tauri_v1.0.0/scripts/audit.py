from pathlib import Path
import re,json,hashlib,sys
p=Path('src/index.html'); t=p.read_text('utf-8')
portable=Path('portable/GDScript_Lab_Godot47_v1.0.0.html')
EXPECTED_PORTABLE='743e2f2d038681473ee20989892f6a306f758b4d03ff4e9989826e082daab822'
EXPECTED_COURSE='569bc1d6e94096f495345274bc5083053e1d5fd9af4262d4549cb08cde6b5880'
m=re.search(r'window\.COURSE_DATA\s*=\s*',t)
if not m: raise SystemExit('COURSE_DATA missing')
s=m.end();d=0;ins=False;esc=False;e=None
for i,ch in enumerate(t[s:],s):
    if ins:
        if esc: esc=False
        elif ch=='\\': esc=True
        elif ch=='"': ins=False
    else:
        if ch=='"': ins=True
        elif ch=='{': d+=1
        elif ch=='}':
            d-=1
            if d==0:e=i+1;break
raw=t[s:e]; D=json.loads(raw)
assert len(D['modules'])==27
assert len(D['lessons'])==171
assert sum(len(x.get('codes',[])) for x in D['lessons'])==183
assert len(D['glossary'])==310 and len(D['reference'])==143 and len(D['projects'])==10
assert hashlib.sha256(raw.encode()).hexdigest()==EXPECTED_COURSE
assert portable.exists() and hashlib.sha256(portable.read_bytes()).hexdigest()==EXPECTED_PORTABLE
assert 'window.__TAURI__' in t
assert 'api.dialog.save' in t and 'api.fs.writeTextFile' in t and 'api.opener.openUrl' in t
assert 'viewport-fit=cover' in t
assert "connect-src ipc: http://ipc.localhost" in t
assert "connect-src 'none'" not in t
assert not re.search(r'\b(fetch|XMLHttpRequest|WebSocket|EventSource|sendBeacon)\s*\(',t)
assert '© 2025–2026 Journey Beyond Horizons Productions (JBH PRODS). All rights reserved.' in t
assert not re.search(r'<button\b(?![^>]*\btype\s*=)',t,re.I)

# Native capability hardening: only Save, scoped HTTPS opener, and text writes.
for cap_name in ['src-tauri/capabilities/desktop.json','src-tauri/capabilities/mobile.json']:
    cap=json.loads(Path(cap_name).read_text('utf-8'))
    perms=cap.get('permissions',[])
    assert 'dialog:allow-save' in perms
    assert 'dialog:default' not in perms
    assert 'opener:allow-default-urls' not in perms
    opener=[x for x in perms if isinstance(x,dict) and x.get('identifier')=='opener:allow-open-url']
    assert len(opener)==1
    urls={x.get('url') for x in opener[0].get('allow',[])}
    assert urls=={'https://docs.godotengine.org/**','https://godotengine.org/**','https://jbhprods.com/**'}
    assert 'fs:allow-write-text-file' in perms

# User-clickable source/product links stay on the three scoped hosts. URLs inside
# learner code examples (for example httpbin.org) are text and are not opener links.
from urllib.parse import urlparse
clickable_urls=[]
for lesson in D['lessons']:
    clickable_urls.extend(str(src.get('url','')) for src in lesson.get('sources',[]) if src.get('url'))
clickable_urls += ['https://jbhprods.com/','https://jbhprods.com/dreamcatcher/']
external_hosts={urlparse(u).hostname for u in clickable_urls}
assert external_hosts <= {'docs.godotengine.org','godotengine.org','jbhprods.com'}


# Native project metadata/toolchain invariants.
pkg=json.loads(Path('package.json').read_text('utf-8'))
assert pkg['version']=='1.0.0'
assert pkg['devDependencies']['@tauri-apps/cli']=='2.11.4'
conf=json.loads(Path('src-tauri/tauri.conf.json').read_text('utf-8'))
assert conf['identifier']=='com.jbhprods.gdscriptlab' and conf['version']=='1.0.0'
assert conf['bundle']['android']['minSdkVersion']==24
assert conf['bundle']['iOS']['minimumSystemVersion']=='14.0'
assert conf['bundle']['macOS']['minimumSystemVersion']=='10.15'
assert conf['app']['withGlobalTauri'] is True
assert conf['app']['security']['csp'] is None
rt=Path('rust-toolchain.toml').read_text('utf-8')
assert 'channel = "1.98.0"' in rt
cargo=Path('src-tauri/Cargo.toml').read_text('utf-8')
for exact in ['=2.5.6','=2.11.5','=2.5.4','=2.7.3','=2.5.1']:
    assert exact in cargo

# CI hardening invariants.
android_wf=Path('.github/workflows/android-build.yml').read_text('utf-8')
desktop_wf=Path('.github/workflows/desktop-build.yml').read_text('utf-8')
ios_wf=Path('.github/workflows/ios-build.yml').read_text('utf-8')
for wf in [android_wf,desktop_wf,ios_wf]:
    assert 'actions/setup-node@v6' in wf and "node-version: '22.16.0'" in wf
    assert 'actions/setup-python@v7' in wf and "python-version: '3.13'" in wf
    assert 'dtolnay/rust-toolchain@1.98.0' in wf
assert "if: ${{ secrets." not in android_wf
assert "if: ${{ env.ANDROID_KEY_BASE64 != '' }}" in android_wf
assert 'android-actions/setup-android@v4' in android_wf
assert 'platforms;android-36' in android_wf and 'build-tools;36.0.0' in android_wf
assert "ndk;27.2.12479018" in android_wf
for dep in ['libwebkit2gtk-4.1-dev','libxdo-dev','libssl-dev','libayatana-appindicator3-dev','librsvg2-dev']:
    assert dep in desktop_wf
assert 'brew install cocoapods || true' not in ios_wf

# Native failures must not silently fall back to browser-only behavior.
assert 'Native export failed; using WebView fallback.' not in t
assert "else window.open(href" not in t

# No remote web content is loaded by markup; HTTPS is only user-initiated through opener.
assert not re.search(r'<(?:script|img|iframe|link)\b[^>]*(?:src|href)=["\']https?://',t,re.I)
print('PASS')
print('frontend_sha256',hashlib.sha256(p.read_bytes()).hexdigest())
print('portable_sha256',hashlib.sha256(portable.read_bytes()).hexdigest())
print('course_data_sha256',hashlib.sha256(raw.encode()).hexdigest())
print('inventory',len(D['modules']),len(D['lessons']),sum(len(x.get('codes',[])) for x in D['lessons']),len(D['glossary']),len(D['reference']),len(D['projects']))
