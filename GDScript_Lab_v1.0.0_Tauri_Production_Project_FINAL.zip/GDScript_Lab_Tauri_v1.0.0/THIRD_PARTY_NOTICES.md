# Third-Party Notices — Build Requirement

GDScript Lab itself is proprietary under `LICENSE.txt`. The native Tauri edition also contains third-party open-source software.

Direct native dependencies in this source project include Tauri 2 and the official opener, dialog and filesystem plugins. Their own licenses remain applicable; the proprietary GDScript Lab license does not replace those licenses.

Because this sandbox cannot resolve the complete Rust dependency graph, this source archive does **not** pretend to contain a complete transitive-license report. The final connected release build should generate that report from the exact `Cargo.lock` used to produce the binary. A standard approach is `cargo-about`:

```bash
cargo install --locked --features cli cargo-about
cd src-tauri
cargo about init
cargo about generate about.hbs > THIRD_PARTY_LICENSES.html
```

Review the generated output and include/retain the notices required by the licenses in the final binary/distribution. License inventory tooling assists compliance but is not legal advice.
