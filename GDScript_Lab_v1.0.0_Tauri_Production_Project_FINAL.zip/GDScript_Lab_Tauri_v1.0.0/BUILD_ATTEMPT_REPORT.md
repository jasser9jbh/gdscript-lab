# GDScript Lab v1.0.0 — Native Build Attempt Report

**Audit/build attempt date:** 2026-09-01  
**Source:** user-supplied `GDScript_Lab_v1.0.0_Tauri_Production_Project(1).zip`

## Executive result

The **Tauri application source is hardened and CI-ready**, and the native JavaScript integration has been executed in Chromium with mocked Tauri APIs. This sandbox could **not** produce genuine native installers because the required native compilers/SDKs are absent and the sandbox cannot download them.

No `.exe`, `.msi`, `.AppImage`, `.deb`, `.apk`, `.aab`, `.dmg` or iOS archive in this package is fake or renamed source content. Native binaries must be produced by the included platform CI workflows or suitable native build hosts.

## Source integrity

- Frozen portable HTML SHA-256: `743e2f2d038681473ee20989892f6a306f758b4d03ff4e9989826e082daab822`
- COURSE_DATA SHA-256: `569bc1d6e94096f495345274bc5083053e1d5fd9af4262d4549cb08cde6b5880`
- COURSE_DATA portable ↔ Tauri: **byte-identical**
- Learner-visible code/command blocks portable ↔ Tauri: **183/183 identical**
- Inventory: **27 modules / 171 lessons / 183 code-command blocks / 310 glossary / 143 reference / 10 projects**

## Native issues found and corrected during this build pass

1. **Tauri IPC CSP blocker fixed.** The native frontend now allows only Tauri's required internal IPC endpoints via `connect-src ipc: http://ipc.localhost`; the portable HTML remains `connect-src 'none'`.
2. **Mobile safe-area sizing hardened.** Notch/system-bar insets are included without double-counting topbar height.
3. **Native capabilities reduced.** Dialog permission is Save-only; opener URLs are scoped to the actual Godot/JBH PRODS domains; filesystem permission is text-write only.
4. **Native export failure behavior hardened.** A packaged app no longer silently falls back to a WebView Blob download if its native export API fails.
5. **Native external-link failure behavior hardened.** A packaged app no longer falls back to an unmanaged `window.open` when the native opener is unavailable.
6. **Android signing helper fixed.** The old helper would have emitted literal escaped newline sequences into Kotlin Gradle content; it now writes valid Kotlin and was unit-tested for idempotency.
7. **GitHub Actions secret conditional fixed.** Android signing no longer references a secret directly in `if:`; repository secrets are exposed as job environment variables and the step checks the environment variable.
8. **Android CI updated.** Uses `android-actions/setup-android@v4`, Android platform/build tools 36, NDK `27.2.12479018`, Java 17 and all four Rust Android targets.
9. **Linux CI prerequisites corrected.** Uses the current WebKitGTK 4.1 / Ayatana / OpenSSL / libxdo / librsvg Tauri prerequisites on Ubuntu 22.04.
10. **Toolchain reproducibility improved.** CI pins Node 22.16.0 and Rust 1.98.0; direct Tauri/plugin crate versions remain exact-pinned.
11. **macOS deployment floor made explicit.** `minimumSystemVersion` is set to 10.15.

## Validation completed in this sandbox

### Static/source audit

`python scripts/audit.py` → **PASS**

Verified:

- exact frozen-course hashes and inventory;
- native Tauri API adaptations;
- native IPC CSP allowance;
- no automatic `fetch`, XHR, WebSocket, EventSource or beacon use;
- no remote script/image/iframe assets;
- button typing and copyright presence;
- minimal capabilities and exact opener URL scopes.

### JavaScript syntax

Both inline JavaScript programs in the portable HTML and both in the Tauri frontend passed `node --check`.

### Configuration syntax

All JSON and TOML files parse successfully. All three GitHub Actions YAML workflows parse successfully with PyYAML.

### Native-mock browser regression

The final Tauri frontend was loaded in system Chromium with mocked `window.__TAURI__` APIs:

- all top-level learning views rendered;
- native Save dialog mock invoked;
- native filesystem `writeTextFile` mock invoked;
- Dreamcatcher link invoked native `openUrl` with `https://jbhprods.com/dreamcatcher/`;
- **171/171 lessons rendered successfully**;
- **0 lessons failed**;
- **0 horizontal page overflows at 320 px**;
- **0 page errors**;
- **0 console errors**.

Failure-path test:

- missing native fs API produced a visible export error and **no browser download fallback**;
- missing native opener produced a visible external-link error;
- **0 page errors**.

### Icon validation

PNG, ICO and ICNS application icon assets were inspected and recognized as valid image/icon formats. Required PNG dimensions are present.

## Actual native compilation attempt / environment blockers

This sandbox is Debian/Linux x86_64 and contains Node 22.16.0 and Java 21, but it does not contain the native Tauri build chain.

Observed blockers:

- `rustc`: **not installed**
- `cargo`: **not installed**
- WebKitGTK 4.1 development package: **not installed**
- GTK 3 development package: **not installed**
- librsvg development package: **not installed**
- Android `sdkmanager`: **not installed**
- Android `adb`: **not installed**
- Android SDK/NDK environment: **not installed/configured**
- Xcode/xcodebuild: **not available on Linux**
- npm Tauri CLI package is not cached locally
- sandbox outbound package/network access is unavailable, so missing Rust/npm/Android packages cannot be downloaded here

An explicit `npm install --offline` attempt failed with `ENOTCACHED` for `@tauri-apps/cli`.

Therefore a genuine Linux or Android binary cannot be linked in this sandbox, and Windows/macOS/iOS binaries intrinsically require their appropriate build environments.

## What remains before a public native binary can truthfully be called production-ready

1. Run the included native CI workflow or a connected native build host.
2. Preserve generated dependency lock files for the final release tag.
3. Generate/review the third-party license inventory from that locked graph.
4. Sign the Windows/Android/macOS/iOS artifacts with private credentials as applicable.
5. Perform the real-device/OS smoke test in `README_DISTRIBUTION.md`.
6. Publish only those signed/tested artifacts.

The educational HTML/course itself does not require another content rewrite for the native build.
