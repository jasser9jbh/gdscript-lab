# GDScript Lab v1.0.0 — Production Distribution

## Recommended public deliverables

- Windows: signed NSIS `.exe` (optional `.msi` too)
- Android direct: signed universal `.apk`
- Google Play: signed `.aab`
- Linux: `.AppImage` + `.deb`
- macOS: signed + notarized `.dmg` / `.app`
- iOS: App Store/TestFlight archive signed with Apple credentials
- Portable: `portable/GDScript_Lab_Godot47_v1.0.0.html`

## Signing is intentionally not embedded

Private signing keys must never ship in a source archive. Signing therefore remains a private release-environment step.

### Windows

Unsigned builds can run but downloaded installers may trigger SmartScreen. For a public commercial release, sign the final installer using your Windows code-signing setup.

### Android

Create one permanent upload keystore and back it up securely. Never commit it. The included Android GitHub workflow supports:

- `ANDROID_KEY_BASE64`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEYSTORE_PASSWORD` (optional)

If signing secrets are absent the workflow can still compile validation artifacts, but do not publish them as the production Android release.

### macOS / iOS

Use Apple Developer certificates, provisioning, notarization/App Store credentials, and the corresponding private secrets. Do not put certificate private keys or passwords in the repository.

## Required pre-publication smoke test

For **each signed native artifact**, test on a real target OS/device before upload:

1. fresh install and first launch;
2. Home, Learn, Reference, Practice, Review, Glossary, Progress, Readiness, About;
3. several early/middle/final lessons;
4. search and decoder;
5. progress persists after app restart;
6. JSON export + re-import;
7. Markdown exports;
8. external Godot documentation link opens the system browser;
9. Dreamcatcher link opens the system browser;
10. no unexpected automatic network request;
11. mobile portrait/landscape safe areas and keyboard behavior;
12. Android system Back behavior (drawer/dialog/navigation/exit) on the devices you support;
13. uninstall/reinstall behavior and backup warning;
14. app icon, title, version, publisher and installer metadata.

## Updates

No automatic updater is enabled in v1.0.0. This is intentional because GDScript Lab promises no automatic network requests. Publish later installers/APKs as explicit user-chosen updates unless that privacy promise is deliberately changed in a future release.

## Third-party software licenses

The native application incorporates Tauri and Rust dependencies. Before the final public binary release, generate/retain the third-party license inventory from the actual locked dependency graph used for that release. `THIRD_PARTY_NOTICES.md` explains the release requirement.
