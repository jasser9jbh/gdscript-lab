#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    gdscript_lab_lib::run();
}
